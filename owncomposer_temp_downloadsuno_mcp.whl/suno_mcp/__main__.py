"""Allow running the package as a module: python -m suno_mcp"""

from .server import main

if __name__ == "__main__":
    main()
